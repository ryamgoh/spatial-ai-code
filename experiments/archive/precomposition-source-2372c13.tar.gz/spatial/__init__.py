"""Versioned spatial reasoning implementations."""
