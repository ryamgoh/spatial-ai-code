"""Public-law tests for the v13 spatial solver.

Run with:
    uv run --python 3.12 --no-project --with pytest --with typer \
      pytest spatial/v1/tests/test_laws_v13.py -q
"""

from __future__ import annotations

import pytest

from spatial.v1.solver_v13 import SpatialSolverV13


SOLVER = SpatialSolverV13()


def prompt(sentences: list[str], question: str, options: dict[str, str]) -> str:
    rendered_options = ", ".join(f"{key}. {value}" for key, value in options.items())
    return (
        "Consider a map with multiple locations:\n\n"
        + " ".join(sentences)
        + f"\n\nQuestion: {question} Available options: {rendered_options}"
    )


DIR_OPTIONS = {
    "A": "Northeast",
    "B": "Northwest",
    "C": "Southeast",
    "D": "Southwest",
    "E": "Cannot be determined",
}


def test_cardinal_facts_compose_into_a_compound_direction() -> None:
    text = prompt(
        [
            "The Library is to the East of the Bank.",
            "The Library is to the North of the Bank.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    assert SOLVER.solve(text) == "A"


def test_cardinal_relations_work_for_which_and_count_questions() -> None:
    sentences = [
        "The Library is to the East of the Bank.",
        "The Museum is to the East of the Library.",
        "The Park is to the West of the Bank.",
    ]
    which_text = prompt(
        sentences,
        "Which object is in the East of the Bank?",
        {
            "A": "Library",
            "B": "Museum",
            "C": "Park",
            "D": "Bank",
            "E": "None of the Options",
        },
    )
    count_text = prompt(
        sentences,
        "How many objects are in the East of the Bank?",
        {"A": "0", "B": "1", "C": "2", "D": "3", "E": "None of the Options"},
    )

    assert SOLVER.solve(which_text) == "A,B"
    assert SOLVER.solve(count_text) == "C"


def test_analysis_reports_independent_shortest_axis_proofs() -> None:
    text = prompt(
        [
            "The Museum is to the East of the Bank.",
            "The Library is to the East of the Museum.",
            "The Park is to the North of the Bank.",
            "The Library is to the North of the Park.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    analysis = SOLVER.analyze(text)

    assert analysis["relation_mix"] == "cardinal-only"
    assert analysis["x_depth"] == 2
    assert analysis["y_depth"] == 2
    assert analysis["x_direct"] is False
    assert analysis["y_direct"] is False
    assert analysis["axes_independent"] is True
    assert analysis["x_path"] == ["Bank", "Museum", "Library"]
    assert analysis["y_path"] == ["Bank", "Park", "Library"]


def test_analysis_marks_shared_diagonal_evidence() -> None:
    text = prompt(
        ["The Library is to the Northeast of the Bank."],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    analysis = SOLVER.analyze(text)

    assert SOLVER.solve(text) == "A"
    assert analysis["relation_mix"] == "diagonal-only"
    assert analysis["x_depth"] == 1
    assert analysis["y_depth"] == 1
    assert analysis["axes_independent"] is False
    assert analysis["shared_supporting_statements"] == [0]


def test_analysis_keeps_unknown_axis_depth_empty() -> None:
    text = prompt(
        ["The Library is to the East of the Bank."],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    analysis = SOLVER.analyze(text)

    assert SOLVER.solve(text) == "A,C"
    assert analysis["x_depth"] == 1
    assert analysis["y_depth"] is None
    assert analysis["axes_independent"] is None


def test_cardinal_cycle_is_not_a_definite_order() -> None:
    text = prompt(
        [
            "The Library is to the East of the Bank.",
            "The Bank is to the East of the Library.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    grade = SOLVER.grade(text)
    analysis = SOLVER.analyze(text)

    assert grade.raw == "E"
    assert grade.x_conflict is True
    assert analysis["x_conflict"] is True


def test_solve_and_analyze_returns_one_authoritative_result() -> None:
    text = prompt(
        [
            "The Museum is to the East of the Bank.",
            "The Library is to the East of the Museum.",
            "The Library is to the North of the Bank.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    solved = SOLVER.solve_and_analyze(text)

    assert solved.grade.raw == "A"
    assert solved.structure["x_depth"] == 2
    assert solved.structure["y_depth"] == 1
    assert solved.structure == SOLVER.analyze(text)


def test_reported_paths_follow_low_to_high_axis_order_for_west_and_south() -> None:
    text = prompt(
        [
            "The Museum is to the West of the Bank.",
            "The Library is to the West of the Museum.",
            "The Park is to the South of the Bank.",
            "The Library is to the South of the Park.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    solved = SOLVER.solve_and_analyze(text)

    assert solved.grade.x_rel == "lt"
    assert solved.grade.y_rel == "lt"
    assert solved.structure["x_path"] == ["Library", "Museum", "Bank"]
    assert solved.structure["y_path"] == ["Library", "Park", "Bank"]


def test_solver_classifies_query_branch_and_disconnected_distractors() -> None:
    text = prompt(
        [
            "The Museum is to the East of the Bank.",
            "The Library is to the East of the Museum.",
            "The Park is to the North of the Bank.",
            "The Library is to the North of the Park.",
            "The Zoo is to the West of the Bank.",
            "The Pharmacy is to the Northeast of the Hospital.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    structure = SOLVER.solve_and_analyze(text).structure

    assert structure["relevant_statement_indices"] == [0, 1, 2, 3]
    assert structure["distractor_statement_indices"] == [4, 5]
    assert structure["query_branch_distractor_statement_indices"] == [4]
    assert structure["disconnected_distractor_statement_indices"] == [5]
    assert structure["num_relevant_relations"] == 4
    assert structure["num_distractor_relations"] == 2


@pytest.mark.parametrize(
    "question,options",
    [
        (
            "In which direction is the Library relative to the Bank?",
            {
                "A": "Northeast",
                "B": "Northwest",
                "C": "Southeast",
                "D": "Southwest",
                "E": "Cannot be determined",
            },
        ),
        (
            "Which object is in the East of the Bank?",
            {
                "A": "Library",
                "B": "Museum",
                "C": "Zoo",
                "D": "Park",
                "E": "Cannot be determined",
            },
        ),
        (
            "How many objects are in the East of the Bank?",
            {
                "A": "0",
                "B": "1",
                "C": "2",
                "D": "3",
                "E": "Cannot be determined",
            },
        ),
    ],
)
def test_any_global_cycle_overrides_every_question_family(
    question: str, options: dict[str, str]
) -> None:
    text = prompt(
        [
            "The Library is to the East of the Bank.",
            "The Museum is to the North of the Zoo.",
            "The Zoo is to the North of the Park.",
            "The Park is to the North of the Museum.",
        ],
        question,
        options,
    )

    solved = SOLVER.solve_and_analyze(text)

    assert solved.grade.raw == "E"
    assert solved.structure["world_consistency"] == "inconsistent"
    assert solved.structure["question_family"] in {"direction", "which", "count"}
    assert solved.structure["semantic_subtype"] is None
    assert solved.structure["cycle_axes"] == ["y"]
    assert solved.structure["cycle_topology"] == "indirect"
    assert solved.structure["cycle_placement"] == "disconnected"
    assert solved.structure["cycle_witnesses"]["y"][0] == (
        solved.structure["cycle_witnesses"]["y"][-1]
    )


def test_consistent_world_is_not_overridden() -> None:
    text = prompt(
        [
            "The Library is to the East of the Bank.",
            "The Library is to the North of the Bank.",
        ],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )

    solved = SOLVER.solve_and_analyze(text)

    assert solved.grade.raw == "A"
    assert solved.structure["world_consistency"] == "consistent"
    assert solved.structure["question_family"] == "direction"
    assert solved.structure["semantic_subtype"] == "dir-1"
    assert solved.structure["cycle_axes"] == []


def test_v13_solver_is_not_a_v6_solver_subclass() -> None:
    from spatial.v1.solver import SpatialSolver

    assert not issubclass(SpatialSolverV13, SpatialSolver)


def test_v13_partial_information_and_missing_option_are_distinct() -> None:
    one_axis = prompt(
        ["The Library is to the East of the Bank."],
        "In which direction is the Library relative to the Bank?",
        DIR_OPTIONS,
    )
    omitted = prompt(
        [
            "The Library is to the East of the Bank.",
            "The Library is to the North of the Bank.",
        ],
        "In which direction is the Library relative to the Bank?",
        {
            "A": "Northwest",
            "B": "Southeast",
            "C": "Southwest",
            "D": "North",
            "E": "None of the Options",
        },
    )

    assert set(SOLVER.solve(one_axis).split(",")) == {"A", "C"}
    assert SOLVER.solve(omitted) == "E"


def test_v13_which_and_count_mean_logically_proven_entities() -> None:
    sentences = [
        "The Library is to the East of the Bank.",
        "The Museum is to the East of the Library.",
        "The Zoo is to the North of the Bank.",
    ]
    which_text = prompt(
        sentences,
        "Which object is in the East of the Bank?",
        {
            "A": "Library",
            "B": "Museum",
            "C": "Zoo",
            "D": "Bank",
            "E": "None of the Options",
        },
    )
    count_text = prompt(
        sentences,
        "How many objects are in the East of the Bank?",
        {"A": "0", "B": "1", "C": "2", "D": "3", "E": "None of the Options"},
    )

    assert SOLVER.solve(which_text) == "A,B"
    assert SOLVER.solve(count_text) == "C"
