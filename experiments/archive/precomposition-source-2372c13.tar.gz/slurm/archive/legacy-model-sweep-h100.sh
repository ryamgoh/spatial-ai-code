#!/bin/bash
#SBATCH --job-name=spatialeval_h100
#SBATCH --partition=gpu-long
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=2-00:00:00
#SBATCH --gres=gpu:h100-47:1 
#SBATCH --output=slurm/archive/logs/%x-%j.out
#SBATCH --error=slurm/archive/logs/%x-%j.err

set -euo pipefail
cd "$SLURM_SUBMIT_DIR"
# #SBATCH --cpus-per-task and SLURM_CPUS_PER_TASK must never differ (Slurm 23+).
# shellcheck disable=SC1091
source "${SLURM_SUBMIT_DIR:-$(cd "$(dirname "$0")" && pwd)}/slurm/lib/pin-srun-cpus.sh"
 
# FINETUNING
# export OMP_NUM_THREADS=16
# export MKL_NUM_THREADS=16
# export PYTORCH_ALLOC_CONF=expandable_segments:True
#
# export AXOLOTL_NO_TELEMETRY=1
# export AXOLOTL_DO_NOT_TRACK=1
# cd finetune
# srun uv sync
# srun --cpu-bind=cores uv run python finetune.py ../experiments/03-sft-vs-baseline/train-sft-8b.yaml
# cd ../eval

# EVAL
cd eval
srun uv sync
# configs now live in ../experiments/<experiment>/ (paths below are from this dir)
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/Cosmos-Reason2_8B_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/Cosmos-Reason2_8B_NonFinetuned_nonshot_2.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/Falcon-H1R-7B_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/Falcon-H1R-7B_NonFinetuned_nonshot_2.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/RoboBrain2.5-8B-NV_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/RoboBrain2.5-8B-NV_NonFinetuned_nonshot_2.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/SpaceQwen3-VL-2B-Thinking_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/SpaceQwen3-VL-2B-Thinking_nonshot_2.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/SpaceR_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/other_models/SpaceR_NonFinetuned_nonshot_2.yaml
srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/experiments_two/Ministral-3-8B-Instruct-2512-BF16_Baseline.yaml
srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/experiments_two/gemma-3-12b-it_Baseline.yaml
srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/experiments_two/Mistral-NeMo-12B-Instruct_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/experiments_two/cogito-v1-preview-llama-8B_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/experiments_two/DeepSeek-R1-Distill-Llama-8B_Baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/02-spatial-baseline-models/experiments_two/NVIDIA-Nemotron-3-Nano-4B-BF16_Baseline.yaml
