#!/bin/bash
#SBATCH --job-name=spatialeval_long_two
#SBATCH --partition=gpu-long
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=1-00:00:00
#SBATCH --gres=gpu:h100-47:1 
#SBATCH --output=slurm/archive/logs/%x-%j.out
#SBATCH --error=slurm/archive/logs/%x-%j.err

set -euo pipefail
cd "$SLURM_SUBMIT_DIR"
# #SBATCH --cpus-per-task and SLURM_CPUS_PER_TASK must never differ (Slurm 23+).
# shellcheck disable=SC1091
source "${SLURM_SUBMIT_DIR:-$(cd "$(dirname "$0")" && pwd)}/slurm/lib/pin-srun-cpus.sh"
 
# FINETUNING
# export OMP_NUM_THREADS=16
# export MKL_NUM_THREADS=16
# export PYTORCH_ALLOC_CONF=expandable_segments:True
#
# export AXOLOTL_NO_TELEMETRY=1
# export AXOLOTL_DO_NOT_TRACK=1
# cd finetune
# srun uv sync
# srun --cpu-bind=cores uv run python finetune.py ../experiments/03-sft-vs-baseline/train-sft-8b.yaml
# cd ../eval

# EVAL
cd eval
srun uv sync
# configs now live in ../experiments/<experiment>/ (paths below are from this dir)
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/00-baseline-model/eval-baseline.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/03-sft-vs-baseline/eval-sft-finetuned.yaml
# srun --cpu-bind=cores uv run python eval_new.py --config ../experiments/01-few-shot-prompting/fewshot.yaml
# (removed from repo) Qwen_7B_*/Gemma_12B two-pass configs -> ../experiments/archive/legacy-two-pass/
# (removed from repo) Cosmos_Reason_2_8B, Qwen_3.5_27B_thinking_two_pass, ../configs/evals/*
