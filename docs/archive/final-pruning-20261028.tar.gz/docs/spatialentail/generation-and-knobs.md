# SpatialEntail generation and experiment knobs

This is the historical catalogue of controls exposed by
[`spatial.v2.legacy`](../../spatial/v2/legacy/README.md), not the active atomic
generator or the composition study's release specification. Boolean curriculum
controls and randomized-proof paths have been retired from active generation.
Follow the [composition pivot](../../experiments/spatialentail-composition-v1/pivot_20261026.md)
for new work.

The formal meaning of accepted historical problems is
defined by [Semantics](semantics.md); certificates are defined by
[Certificate system](certificates.md); rendered outputs are defined by
[Trace formats](trace-formats.md).

This guide includes the generation algorithm, rule substitution, sampling
contract, rejection policy, and configuration catalogue. The compact
[generation PDF](../archive/presentations/generation-overview.pdf) and
[rule-substitution PDF](../archive/presentations/rule-substitution.pdf) are presentation views of this
guide, not separate implementation contracts.

The controls below do not belong to the solver. They select, filter, render,
split, or admit problems after the solver has established their semantics.

The research-facing [task taxonomy](../research/task-taxonomy.md) composes query
contract, reasoning structure, semantic status, and evidence burden into
benchmark cells. The current generator exposes the lower-level controls listed
here. The versioned `spatial/v2/benchmark-cells.yaml` registry maps selected
taxonomy cells to representative generator policies; `benchmark_registry.py`
validates declarations and can probe one checked example per ready cell. The
registry contains no quotas; the study assembler adds role and cell metadata.
Existing `boolean_shape` and depth fields must not be relabelled as verified
capabilities without the taxonomy's admission checks.

## Generation algorithm

The randomized proof-backbone route starts from a target or a possibility
skeleton, constructs premises backward, and then checks the visible problem.
This is distinct from the older world-first and premise-first routes below.

```text
GENERATE(query, gold_set_size G, rule_length L, distractors X, policy):
    repeat within the candidate-attempt budget:
        choose distinct object names
        initialise a unique target or a G-answer possibility skeleton
        choose a target premise to expand and account for skeleton length
        sample a policy-feasible forward rule sequence
        traverse the sequence backward:
            match the rule conclusion to the current goal
            instantiate its inputs with compatible objects or formulas
            retain supporting inputs as premises
            make the chain input the next goal
        add the final goal and X distractors; shuffle and remove unused names
        solve all candidate answers; reject inconsistent or undecided problems
        build checked evidence; verify G, L, X and the required rule path
        construct options; render and reparse; reject semantic drift
        return the checked problem, answer, trace, and audit metadata
    report attempt exhaustion; never emit an unverified problem
```

Known candidate rejections are retried; configuration and unexpected errors are
not silently converted into retries. Study-level admission also checks
transitions, structural deduplication, split exclusions, and context budgets.
Timeout means unverified, not unsatisfiable. Contradictory cycles are excluded
from main training; detecting inconsistency is a separate diagnostic.

### Object selection and targets

The current randomized study samples 24 distinct names from a pool of 30,
then removes unused names. This is not the final entity count. The unique
route assigns target/reference roles from the sorted names and samples an
exact compass direction. Name subsets are uniform; object roles are not
independently uniform. Selection/Count use additional query candidates with
exclusion premises. Possibility skeletons shuffle roles and are checked to
preserve exactly G possible answers, not G simultaneously qualifying objects.

For multi-answer lifts, known skeleton offsets are 0 for Direction/Selection
and G for the study's Count skeleton. The randomized prefix has length
`L - offset`; the final certificate must still confirm total length L.

### Rule substitution and chaining

Here S is the current goal and P is an auxiliary exact spatial atom:

| Rule | Supporting premise | Next backward goal |
|---|---|---|
| MP | `P -> S` | `P` |
| IFF elimination | `P <-> S` | `P` |
| Disjunctive syllogism (DJE) | `P OR S` | `NOT P` |
| Double-negation elimination (DN) | none | `NOT NOT S` |
| Transitivity (TRC), for `S = D(A,B)` | `D(M,B)` | `D(A,M)` |

Bindings must match the goal and satisfy object/formula constraints.
TRC inherits the exact direction D and requires a distinct intermediate M.
All generated spatial atoms use the eight exact compass directions, not
explicit northward/eastward predicates. The constructor implements five
specific templates, not a general-purpose unifier.

Example: to establish `NE(A,B)` using the forward path `MP -> TRC`, backward
construction emits `P`, `P -> NE(A,M)`, and `NE(M,B)`. MP derives `NE(A,M)`;
TRC derives `NE(A,B)`. This is intended L2 with three premises, subject to
the certificate's realised-length check.

The constructor supports 23 ordered rule pairs. The two excluded pairs are
`TRC -> DJE` and `TRC -> DN`: TRC supplies a positive exact atom, not their
required negated/double-negated input. Training and query policies restrict
this set further; multi-answer lifts forbid a final TRC. Pair compatibility
alone does not guarantee an accepted full chain.

### Uniformity and admission

The sampler counts feasible suffixes and weights each next rule by its number
of valid completions. This makes complete proposed paths uniform conditional
on length, allowed transitions, and policy restrictions. It does not make
individual rule frequencies, object roles, or accepted problems uniform:
instantiation, consistency, certificate search, and deduplication can reject
different paths at different rates.

The implementation-level details are maintained in the source:
[`random_proof.py`](../../spatial/v2/legacy/random_proof.py),
[`random_proof_generation.py`](../../spatial/v2/legacy/random_proof_generation.py),
and [`generation.py`](../../spatial/v2/legacy/generation.py).

## Knob classes

The configuration surface contains four different kinds of control:

1. **Problem controls** change the query, formula, answer contract, or menu.
2. **Difficulty controls** require measured properties of accepted evidence.
3. **Supervision controls** change what is printed for the same accepted base
   problem.
4. **Experiment controls** govern sampling, splitting, and token admission.

These categories should not be conflated. In particular, a requested template
is a generation condition; measured proof depth and semantic support describe
the accepted problem.

## Complete policy catalogue

### Problem semantics and questions

| Field | Values | Effect | Important constraints |
|---|---|---|---|
| `query_kind` | `direction`, `which`, `count` | Selects the question and certificate family. | Direction compares one target/reference pair. Which and Count use declared candidates and a requested relation set. |
| `semantic_shape` | `any`, `unique`, `ambiguous`, `multiple-certain`, `no-match` | Filters the all-model answer domain. | `multiple-certain` and `no-match` apply only to Selection. Controlled proof-depth cells require `unique`. |
| `ambiguity_size` | integer ≥ 2 or omitted | Requires exactly this many possible semantic answers. | Applies to ambiguous cells; the feasible maximum depends on the query domain. |
| `query_direction` | one of eight exact directions or omitted | Fixes the requested membership direction for Which/Count. | Invalid for Direction queries. Matrix files can enumerate `query_directions`. |
| `target_direction` | one of eight exact directions or omitted | Requires a particular unique Direction answer. | Requires a Direction query and `semantic_shape: unique`. Matrix files can enumerate `target_directions`. |

The exact directions are North, Northeast, East, Southeast, South, Southwest,
West, and Northwest. Direction-sensitive structural signatures do not identify
rotated problems.

The implementation value `which` maps to the research-facing Entity Selection
(`SEL`) family. The alias makes the singular selection contract explicit; it
does not alter stored schemas or source SpatialMap labels.

### Answer and menu contract

| Field | Values | Effect | Important constraints |
|---|---|---|---|
| `answer_mode` | `single`, `all-possible`, `visible-possible` | Defines whether the answer is one invariant result, the complete semantic possibility set, or only visible possible menu values. | `visible-possible` is diagnostic rather than headline exact semantics. |
| `menu_coverage` | `full`, `partial`, `zero` | Controls whether all, some, or none of the semantic answers occur as ordinary menu options. | `partial` is undefined for `single`. |
| `ordinary_option_target` | 1–25 | Sets the requested number of ordinary menu entries before any special answer. | Exposed by `GenerationPolicy`; the strict matrix currently uses its policy default. |
| `menu_option_count` | positive integer or unset | Fixes the total menu size after reserving any special option. | Randomized v2 sets five, so V0 uses four ordinary distractors plus `None of the Options`. |
| `visible_gold_size` | 0 through G or unset | Controls how many semantic possibilities remain displayed under `VISIBLE_POSSIBLE`. | Zero requires zero coverage; a positive proper subset requires partial coverage. |

All ordinary and special options participate in one seeded final shuffle.
`Cannot be determined` and `None of the Options` therefore have no fixed letter.

### Formula and provenance controls

| Field | Values | Effect | Important constraints |
|---|---|---|---|
| `boolean_shape` | `atomic`, `modus-ponens`, `iff`, `double-negation`, `disjunctive-syllogism`, `case-split`, `nested-case-split` | Selects an atomic or Boolean syntax/proof-template family. | Outside premise-first mode, non-atomic shapes require unique/any policy semantics, at least four entities (six for nested cases), and cannot combine with axis-depth, direct-relation omission, independent-axis, or distractor controls. A crossed `WorkloadSpec` is stricter: all non-premise-first non-atomic cells must be `unique`. In premise-first mode the name identifies the sampled syntax family, not a promise that the shortest accepted proof uses the similarly named rule. |
| `generation_mode` | `auto`, `world-first`, `proof-template-first`, `premise-first` | Selects how a candidate problem is proposed. | World-first supports atomic premises only. Unsupported combinations fail instead of silently rerouting. |

The recorded provenance reflects the route actually used:

- **world-first:** propose a coordinate world, discard its answer, and re-solve
  the visible premises;
- **proof-template-first:** instantiate a controlled formula/proof family, then
  solve and certify it;
- **premise-first:** sample visible formulas before choosing the query, then
  solve, classify, and certify without an answer-bearing map;
- **auto:** choose the supported route implied by the policy.

For atomic Direction policies with `semantic_shape: ambiguous` and
`ambiguity_size: 2`, auto mode uses a constructive template when the premises
form a spanning tree. Both queried objects are constrained to the same value on
one axis relative to a shared pivot, while their order on the other axis remains
open. The solver must therefore confirm exactly the opposite pair North/South
or East/West. This constructs only the visible premises and query; it does not
derive them from an answer-bearing coordinate map.

`certificate-first` remains vocabulary for a stricter proposed construction and
is not an implemented `GenerationMode`.

### Size and measured difficulty

| Field | Values | Effect | Important constraints |
|---|---|---|---|
| `num_entities` | 2–30 | Controls the named-object domain. | Thirty is the current name-pool size, not a semantic solver limit. |
| `num_premises` | connected minimum through all unordered pairs | Controls visible formula count. | The generator requires enough premises to connect the selected entities. |
| `omit_direct_query_relation` | Boolean | Forbids a premise that directly states the query relation. | Requires at least three entities and unique controlled semantics. |
| `min_axis_depth`, `max_axis_depth` | positive integers | Bounds measured X/Y proof depth for Direction. | Applies only to unique Direction cells. |
| `min_membership_depth`, `max_membership_depth` | positive integers | Bounds positive membership-proof depth for Which/Count. | Requires at least one entailed member; correlated counts without one do not receive a fabricated depth. |
| `require_independent_axes` | Boolean | Requires X and Y conclusions to depend on disjoint supporting premises. | Requires the relevant minimum depth to be at least two. |
| `distractor_premises` | non-negative integer | Requires this many jointly removable premises after preserving answer and membership semantics. | Supported for Direction and controlled-depth Selection; Count remains unsupported. No greater than `num_premises`. Support is sufficient and order-dependent, not globally minimum. Incomplete semantic checks retain premises and set `support_checks_complete: false`. |
| `require_joint_count_dependency` | Boolean | Requires possible Count values to be stricter than the interval implied by independent candidate-membership marginals. | Count-only; currently constructed as a unique case-split/XOR obligation. |
| `possibility_candidate_count` | positive integer or unset | Limits the declared Selection/Count candidate domain while leaving spare objects for proof structure and noise. | Must exceed the requested gold size for generic possibility skeletons. |

Randomized proof-graph v2 additionally measures certificate-derived semantic
length `L` and exact verified distractor count `X`. These are not aliases for
the older axis/membership depths. See `docs/archive/audits/randomized-proof-v2-design.md`.

Difficulty is measured on accepted problems. Generator intent alone does not
establish the reported depth, independence, or distractor count.

### Coupled feasibility rules

The constructor rejects impossible combinations before sampling:

- `num_premises` must be at least `num_entities - 1` and no greater than the
  number of unordered entity pairs;
- requested proof depth cannot exceed either `num_entities - 1` or
  `num_premises`;
- direct-relation omission requires at least three entities, and a protected
  pair cannot be omitted when the premise budget already consumes every pair;
- independent axes require depth at least two and reserve twice the requested
  depth, so `2 × depth + distractor_premises` must fit the premise budget;
- without independent axes, `depth + distractor_premises` must fit;
- `ambiguity_size` requires ambiguous semantics and cannot exceed eight for
  Direction, `num_entities - 1` for Selection, or `num_entities` for Count; and
- depth, independent-axis, direct-omission, and distractor controls require
  unique semantics. Membership depth is invalid for Direction; axis depth is
  invalid for Which/Count.

These are compatibility rules, not suggestions. Invalid cells fail before an
attempt loop; feasible but selective cells may still exhaust
`max_attempts_per_sample` and report their rejection histogram.

## Rendering and artifact catalogue

| Field | Values | Effect | Important constraints |
|---|---|---|---|
| `trace_format` | `natural`, `symbolic` | Selects controlled prose or versioned replayable NDJSON. | Natural is the verified worked-solution view used by central SFT. Symbolic is an offline replay/audit artifact, not the future compact CoS-like format. |
| `supervision_arm` | `checked-trace`, `answer-only`, `corrupted-trace` | Selects valid evidence, no evidence, or a deliberately invalid verifier fixture with the same answer. | Central SFT uses answer-only or checked Natural. `corrupted-trace` is retained only to test that Symbolic replay fails closed; it is not a training arm. |
| `include_audit` | Boolean | Adds full certificate and coordinate-bearing generation witness metadata. | Audit metadata is never an SFT target. |

Natural and Symbolic rows originate from the same checked certificate, problem,
menu, and gold answer. They validate renderer agreement, but have different
responsibilities: Natural may supply central SFT targets, while Symbolic is
retained for offline replay and dataset audits.

## Workload and split catalogue

| Field | Values | Effect | Important constraints |
|---|---|---|---|
| `samples_per_cell` / matrix `count` | non-negative / positive integer | Requests accepted base problems per crossed cell. | A direction-enumerated cell applies `count` per listed direction. |
| `seed` | integer | Controls reproducible proposal, menu, group, and split shuffling. | Record it with the generated manifest and software revision. |
| `max_attempts_per_sample` | positive integer | Bounds rejection sampling for each requested base. | Exhaustion reports the rejection histogram. |
| `dev_split`, `test_split` | fractions in `[0,1)` | Requests three-way train/development/test allocation. | Their sum must be below one. Development selects checkpoints; test is final only. |
| `split_strategy` | `random`, `structural`, `holdout` | Selects base-group splitting, canonical-structure clustering, or declared-cell routing. | Paired variants never cross splits. Holdout cell declarations must agree with requested dev/test presence. |
| `holdout_cells` | named dev/test cell lists | Reserves predeclared matrix cells. | Used only with `holdout`; listed cells must exist and be disjoint. |
| `replace` | Boolean | Authorizes replacing this workload's exact output paths. | Failed admission or validation preserves prior successful data and writes diagnostics. |

### Python workload versus matrix names

`GenerationPolicy` describes one cell and therefore uses singular fields. The
`WorkloadSpec` API crosses collections of values and uses the following plural
fields:

| `WorkloadSpec` field | Per-cell or matrix equivalent |
|---|---|
| `query_kinds` | cell `query_kind` |
| `answer_modes` | named `variants.answers[].mode` |
| `semantic_shapes` | cell `semantic_shape` |
| `menu_coverages` | named `variants.answers[].menu_coverage` |
| `trace_formats` | `variants.traces[].format` |
| `supervision_arms` | `variants.supervision_arms` |
| `boolean_shapes` | cell `boolean_shape` |
| `query_directions` | cell `query_directions` |
| `target_directions` | cell `target_directions` |
| `context_budget` | root `context_budget` mapping |

The remaining `WorkloadSpec` fields use the same singular names documented in
the tables above: `generation_mode`, `num_entities`, `num_premises`,
`omit_direct_query_relation`, both depth ranges, `require_independent_axes`,
`ambiguity_size`, `distractor_premises`, `max_attempts_per_sample`, `dev_split`,
`test_split`, `split_strategy`, `seed`, `include_audit`, and `replace`.

At matrix level, `version`, `seed`, `dev_split`, `test_split`,
`split_strategy`, `holdout_cells`, `context_budget`, `include_audit`, `defaults`,
`variants`, and `cells` are the only accepted root keys. Each cell requires a
unique `name`, requests a base count with `count`, and may restrict named
`answer_variants`; its other fields are the per-cell controls above. Unknown
keys fail validation.

Structural grouping ignores entity names, premise/candidate order, and
commutative operand order. It retains exact directions and implication order.
Exact canonicalization is bounded at 40,320 residual permutations; the fallback
is invariant but coarse and may merge distinct structures. A structural split
is not logical equivalence or a proof-composition holdout.

## Context-admission catalogue

| Field | Meaning |
|---|---|
| `tokenizer_name` | Tokenizer whose chat template and encoding define admission. |
| `tokenizer_revision` | Pinned model/tokenizer revision used by generation, training, and evaluation. |
| `train_max_tokens` | Maximum complete rendered training sequence. |
| `eval_max_tokens` | Maximum rendered evaluation prompt plus generation reserve. |
| `max_new_tokens` | Reserved and enforced generation suffix budget. |
| `target_max_tokens` | Optional stricter completion cap. |

Admission renders with the selected chat template, counts the full sequence,
checks the exact generatable suffix including terminators, and binds the stored
evaluation prompt to its source messages with integrity fingerprints. Every
required variant for a base is accepted or rejected as one group. Failure writes
a durable rejection report instead of silently dropping one representation or
semantic stratum.

## Matrix configuration

```yaml
version: 1
seed: 1515
dev_split: 0.2
test_split: 0.2
split_strategy: structural
include_audit: false

context_budget:
  tokenizer_name: Qwen/Qwen3.5-4B
  tokenizer_revision: 851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a
  train_max_tokens: 4096
  eval_max_tokens: 8192
  max_new_tokens: 4096

defaults:
  num_entities: 3
  num_premises: 2
  max_attempts_per_sample: 2000

variants:
  answers:
    - {name: single, mode: single, menu_coverage: full}
  traces:
    - {format: natural}
  supervision_arms: [checked-trace, answer-only]

cells:
  - name: direction-depth-2
    count: 5
    query_kind: direction
    semantic_shape: unique
    depth: 2
    omit_direct_query_relation: true
    target_directions: [North, Northeast, East, Southeast, South, Southwest, West, Northwest]

  - name: direction-ambiguity-2
    count: 40
    query_kind: direction
    semantic_shape: ambiguous
    ambiguity_size: 2
```

`depth` is matrix shorthand for axis depth on Direction or membership depth on
Which/Count. Unknown keys and unsupported combinations fail validation.

## Current executed preparation coverage

The bounded engineering pilot predates the final SFT boundary and exercises:

- Direction queries;
- unique depth-two versus ambiguity-size-two semantics;
- all eight target directions for the unique cell;
- agreement between Natural rendering and replayable Symbolic certificates;
- answer-only output and corrupted-Symbolic verifier fixtures;
- structural train/development/test splitting;
- identical three-entity/two-premise budgets across semantic strata; and
- pinned Qwen3.5-4B context admission.

Its tokenizer/generator smoke admitted 80 bases and 320 rows, split 48/16/16
bases. Maximum full rendered-row length was 4,032 tokens under the 4,096 limit.
These historical fixture counts do not define the central training packages.

The separate `matrix-premise-holdout.yaml` exercises atomic training,
premise-first IFF development, and premise-first implication testing over 16
bases. These are preparation checks, not trained-model results.

## Commands and outputs

```bash
uv run --python 3.12 --no-project --with typer --with pyyaml \
  --with z3-solver --with transformers --with jinja2 \
  python -m spatial.v2.legacy.generate_matrix \
  experiments/15-v2-ablation/matrix.yaml \
  --out data/spatial_v2_pilot.jsonl
```

Generation writes master train/development/test JSONL, a manifest, rejection
diagnostics when applicable, and materialized `by_variant`/`by_cell` views. The
manifest—not the requested YAML—is the authority for actual counts, paths,
distributions, fingerprints, and admitted token volumes.

The runnable training/evaluation orchestration is documented beside its code in
[`experiments/15-v2-ablation`](../../experiments/15-v2-ablation/README.md).
Training benefits, readable explanation quality, and internal reasoning
faithfulness remain empirical questions.

## Bounded study compositions

`GenerationPolicy.composition` selects MP→TRC, IFF→TRC, TRC→MP, or DJE→TRC seen
families across all query contracts. MP→TRC→MP, MP→DJE→TRC, and
TRC→MP→TRC are separately reserved. Admission requires
replay-valid ordered dependencies and individual logical-premise removal to
change query semantics. These are bounded interventions, not global shortest
proof claims. See [study protocol](../archive/research/size-freeze-protocol.md).
